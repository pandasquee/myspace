# Admin views

Evennia makes several customizations to the Django web admin, but you can make
further changes here. Customizing the admin is a big topic and
you are best off reading more about it in the [Django admin site documentation](https://docs.djangoproject.com/en/4.1/ref/contrib/admin/).
